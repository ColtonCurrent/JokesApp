Empty recycler view and two menu buttons. The add button will delete the contents of the database and insert new jokes into the database.
The clock face will set all of the jokes checkboxes to unchecked, resetting if they were solved. If user clicks on joke, it will bring them to a second activity, this activity
will have a textview, a edittext, and two buttons. The user can enter the punchline of the joke and click one button to see if they got it right, the other button
is if they cannot get it correct. It will automatically set the jokes checkbox to the solved state and reveal the answer on the main page. When the user is in the second
activity a laugh track will play the entire time.