package com.example.finalproject;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;


public class ThreadJoke extends HandlerThread {
    Handler jokeHandler;
    Context context;
    JokeSQLiteHelper jokeSQLiteHelper;

    public ThreadJoke(String name, Handler jokeHandler, Context context) {
        super(name);
        this.jokeHandler = jokeHandler;
        this.context = context;
    }

    @Override
    public void run() {
        jokeSQLiteHelper = new JokeSQLiteHelper(context.getApplicationContext());
        Log.v("help", "before loop");
        for(int i = 1; i <= 25; i++){
            //10.0.2.2
            String index = String.valueOf(i);
            String url = "http://10.0.2.2:5000/jokes?id=" + index;
            RequestQueue queue = Volley.newRequestQueue(context);
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try{
                        JSONObject jsonObject = new JSONObject(response);
                        String joke = jsonObject.getString("Joke");
                        String punchLine = jsonObject.getString("Punchline");
                        jokeSQLiteHelper.insert(joke, punchLine, 0);
                        Message message = Message.obtain();
                        message.what = 1;
                        jokeHandler.sendMessage(message);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, null);
            queue.add(stringRequest);
        }
    }
}
