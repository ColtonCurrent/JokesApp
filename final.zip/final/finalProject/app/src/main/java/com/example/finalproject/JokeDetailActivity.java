package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class JokeDetailActivity extends AppCompatActivity {

    TextView textViewUserOpening;
    EditText editTextUserPunchLine;
    Button buttonSolved;
    Button buttonGiveUp;

    JokeSQLiteHelper jokeSQLiteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_joke_detail);

        jokeSQLiteHelper = new JokeSQLiteHelper(getApplicationContext());

        textViewUserOpening = findViewById(R.id.textViewUserOpening);
        editTextUserPunchLine = findViewById(R.id.editTextUserPunchline);
        buttonSolved = findViewById(R.id.buttonSolved);
        buttonGiveUp = findViewById(R.id.buttonGiveUp);

        int index = getIntent().getIntExtra("Position", 0);

        Joke joke = jokeSQLiteHelper.getJoke(index);

        textViewUserOpening.setText(joke.opening);

        MediaPlayer mp = MediaPlayer.create(this, R.raw.sample);
        mp.start();

        buttonSolved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userAnswer = editTextUserPunchLine.getText().toString();
                String dataAnswer = joke.punchline;

                if(userAnswer.equals(dataAnswer)){
                    jokeSQLiteHelper.update(joke.id, 1);
                    mp.stop();
                    finish();
                }
                else{
                    Toast toast = Toast.makeText(getApplicationContext(), "Incorrect. Try Again.", Toast.LENGTH_LONG);
                    toast.show();
                    editTextUserPunchLine.setText("");
                }
            }
        });

        buttonGiveUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                jokeSQLiteHelper.update(joke.id, 1);
                mp.stop();
                finish();
            }
        });
    }
}