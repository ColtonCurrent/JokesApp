package com.example.finalproject;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class JokeAdapter extends RecyclerView.Adapter {
    JokeSQLiteHelper jokeSQLiteHelper;
    public JokeAdapter(JokeSQLiteHelper jokeSQLiteHelper){
        this.jokeSQLiteHelper = jokeSQLiteHelper;
    }

    public class JokeViewHolder extends RecyclerView.ViewHolder{
        TextView textViewJoke;
        TextView textViewPunchLine;
        CheckBox checkBoxSolved;
        public JokeViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewJoke = itemView.findViewById(R.id.textViewJoke);
            textViewPunchLine = itemView.findViewById(R.id.textViewPunchLine);
            checkBoxSolved = itemView.findViewById(R.id.checkBoxSolved);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    Intent intent = new Intent(view.getContext(), JokeDetailActivity.class);
                    intent.putExtra("Position", position);
                    view.getContext().startActivity(intent);
                }
            });
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.joke_view, parent, false);
        return new JokeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Joke joke = jokeSQLiteHelper.getJoke(position);
        JokeViewHolder jokeViewHolder = (JokeAdapter.JokeViewHolder) holder;
        jokeViewHolder.textViewJoke.setText(joke.opening);
        if(joke.solved == 0){
            jokeViewHolder.checkBoxSolved.setChecked(false);
            jokeViewHolder.textViewPunchLine.setText("");
        }
        else{
            jokeViewHolder.checkBoxSolved.setChecked(true);
            jokeViewHolder.textViewPunchLine.setText(joke.punchline);
        }
    }

    @Override
    public int getItemCount() {
        return jokeSQLiteHelper.getSize();
    }
}
