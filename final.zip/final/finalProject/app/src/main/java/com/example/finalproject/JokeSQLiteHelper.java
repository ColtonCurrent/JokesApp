package com.example.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.BitmapFactory;

import androidx.annotation.Nullable;

import java.io.File;

public class JokeSQLiteHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "JOKE.sqlite";
    private static final int DB_VERSION = 1;
    Cursor cursor = null;
    Context context;

    public JokeSQLiteHelper(Context context){super(context, DB_NAME, null, DB_VERSION);
        this.context = context;}

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String create = "CREATE TABLE Joke (_id INTEGER PRIMARY KEY AUTOINCREMENT, opening TEXT, punchline TEXT, solved NUMBER)";
        sqLiteDatabase.execSQL(create);
    }

    void update(int id, int favorite){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("solved", favorite);
        sqLiteDatabase.update("Joke", contentValues, "_id = ?", new String[]{String.valueOf(id)});
    }

    void updateAll(){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("solved", 0);
        sqLiteDatabase.update("Joke", contentValues, null, null);
    }

    void insert(String opening, String punchline, int solved){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("opening", opening);
        contentValues.put("punchline", punchline);
        contentValues.put("solved", solved);
        sqLiteDatabase.insert("Joke", null, contentValues);
    }

    void delete(){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        sqLiteDatabase.delete("Joke", null, null);
        //if statement doesn't work during testing, add int into parameters and add where clause + args
    }

    int getSize(){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        cursor = sqLiteDatabase.rawQuery("SELECT * FROM Joke", null);
        return cursor.getCount();
    }

    public Joke getJoke(int position) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        cursor = sqLiteDatabase.query("Joke", new String[]{"_id", "opening", "punchline", "solved"}, null, null, null, null, "solved DESC");
        if(cursor.moveToPosition(position)){
            Joke joke = new Joke();
            joke.id = cursor.getInt(0);
            joke.opening = cursor.getString(1);
            joke.punchline = cursor.getString(2);
            joke.solved = cursor.getInt(3);
            return joke;
        }
        return null;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
