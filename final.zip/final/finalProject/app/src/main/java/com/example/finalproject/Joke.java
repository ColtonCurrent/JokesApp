package com.example.finalproject;

public class Joke {
    public int id;
    public String opening;
    public String punchline;
    public int solved;
}
