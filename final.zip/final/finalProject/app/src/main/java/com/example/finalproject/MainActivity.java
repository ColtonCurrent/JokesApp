package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    JokeSQLiteHelper jokeSQLiteHelper;
    RecyclerView recyclerViewJoke;
    JokeAdapter jokeAdapter;

    Handler handler;
    ThreadJoke threadJoke = null; //inside menu buttons

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        jokeSQLiteHelper = new JokeSQLiteHelper(getApplicationContext());
        jokeAdapter = new JokeAdapter(jokeSQLiteHelper);

        recyclerViewJoke = findViewById(R.id.recyclerViewJoke);
        recyclerViewJoke.setAdapter(jokeAdapter);
        recyclerViewJoke.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        handler = new Handler(getMainLooper()){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                if(msg.what == 1){
                    recyclerViewJoke.getAdapter().notifyDataSetChanged();
                }
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.joke_toolbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.itemGetNewJokes){
            jokeSQLiteHelper.delete();
            threadJoke = new ThreadJoke("ThreadJoke", handler, getApplicationContext());
            threadJoke.start();
        }
        else if(id == R.id.itemResetSolved){
            jokeSQLiteHelper.updateAll();
            jokeAdapter.notifyDataSetChanged();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        threadJoke.quit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        jokeAdapter.notifyDataSetChanged();
    }
}