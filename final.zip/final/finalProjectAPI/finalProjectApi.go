package main

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"
)

type Joke struct{
	Joke string
	Punchline string
}

func joke(writer http.ResponseWriter, request *http.Request){
	param, _ := request.URL.Query()["id"]
	id, _ := strconv.Atoi(param[0])

	if id == 1 {
		j := Joke{"How do you have a party in space?", "You planet"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 2 {
		j := Joke{"What is the worst way you can insult a ghost?", "You say get a life"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 3 {
		j := Joke{"Where do fruits go on vacation", "Pear-is"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 4 {
		j := Joke{"What did one wall say to the other?", "I'll meet you at the corner"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 5 {
		j := Joke{"What do a tick and the Eiffel Tower have in common?", "They are both Paris sites"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 6 {
		j := Joke{"Why do fathers take an extra pair of socks when they go golfing?", "In case they get a hole in one"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 7 {
		j := Joke{"What do you call a woman who's really good at darts?", "Amy"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 8 {
		j := Joke{"Why does Spider-Mans calender only have 11 months?", "He lost may"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 9 {
		j := Joke{"What should you do if you are addicated to sea weed?", "Sea kelp"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 10 {
		j := Joke{"What has 3 letters and starts with gas?", "A car"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 11 {
		j := Joke{"Where do bad rainbows go?", "Prism but its a light sentence"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 12 {
		j := Joke{"Where do math teachers go on vacation?", "Times Square"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 13 {
		j := Joke{"How long is a minute?", "It depends on what side of the bathroom you are on"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 14 {
		j := Joke{"What's made of leather and sounds like a sneeze?", "A shoe"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 15 {
		j := Joke{"What do you call an anti-vax nannie?", "Mrs. Doubt Pfizer"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 16 {
		j := Joke{"Why aren't koalas actual bears?", "Because they don't meet the koalafications"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 17 {
		j := Joke{"What kind of bears have no teeth?", "Gummy bears"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 18 {
		j := Joke{"What's the difference between a ruble and a dollar?", "A dollar"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 19 {
		j := Joke{"What did the drummer name his twin daughters?", "Anna one Anna two"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 20 {
		j := Joke{"What happens if someone slaps you at a high frequency?", "It Hertz"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 21 {
		j := Joke{"What do you call a factory that makes okay products?", "A satisfactory"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 22 {
		j := Joke{"Where does Sir Lancelot go to party?", "A knight club"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 23 {
		j := Joke{"What do you call a mouse that swears?", "A cursor"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 24 {
		j := Joke{"How does music say goodbye?", "Audios"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 25 {
		j := Joke{"How does a hamburger introduce his girlfriend?", "Meet patty"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	} else if id == 26 {
		j := Joke{"What do you call a detective who just solves cases accidentally?", "Sheer Luck Holmes"}
		b, _ := json.Marshal(j)
		writer.Write([]byte(b))
	}
}

func main(){
	//10.0.2.2 for android
	http.HandleFunc("/jokes", joke)
	err := http.ListenAndServe("localhost:5000", nil)
	log.Fatal(err)
}